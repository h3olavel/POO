
package proyecto2;

/**
 *
 * @author KARINMOLES
 */
public class LOG    extends javax.swing.JFrame {

    /*String nombre = "admin", clave = "123";*/


    public LOG() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        error = new javax.swing.JLabel();
        ICON = new javax.swing.JLabel();
        Passe = new javax.swing.JPasswordField();
        TFnombre1 = new javax.swing.JTextField();
        Lcontraseña = new javax.swing.JLabel();
        Lnombre = new javax.swing.JLabel();
        LOGIN = new javax.swing.JLabel();
        BTMCERRAR = new javax.swing.JButton();
        FONDO = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        error.setFont(new java.awt.Font("Franklin Gothic Heavy", 0, 14)); // NOI18N
        getContentPane().add(error, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, 210, 60));

        ICON.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images2/Capa 1.png"))); // NOI18N
        getContentPane().add(ICON, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 270, 270));

        Passe.setFont(new java.awt.Font("Showcard Gothic", 0, 14)); // NOI18N
        Passe.setForeground(new java.awt.Color(102, 102, 102));
        Passe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PasseActionPerformed(evt);
            }
        });
        getContentPane().add(Passe, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 190, 210, 40));

        TFnombre1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TFnombre1ActionPerformed(evt);
            }
        });
        getContentPane().add(TFnombre1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 140, 210, 40));

        Lcontraseña.setFont(new java.awt.Font("Century", 1, 18)); // NOI18N
        Lcontraseña.setForeground(java.awt.SystemColor.control);
        Lcontraseña.setText("Contraseña");
        getContentPane().add(Lcontraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 200, -1, -1));

        Lnombre.setFont(new java.awt.Font("Century", 1, 18)); // NOI18N
        Lnombre.setForeground(java.awt.SystemColor.control);
        Lnombre.setText("Usuario");
        getContentPane().add(Lnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 150, -1, -1));

        LOGIN.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images2/ENTRAR.png"))); // NOI18N
        LOGIN.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        LOGIN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LOGINMouseClicked(evt);
            }
        });
        getContentPane().add(LOGIN, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 240, 130, 130));

        BTMCERRAR.setBackground(java.awt.Color.red);
        BTMCERRAR.setFont(new java.awt.Font("Mongolian Baiti", 1, 36)); // NOI18N
        BTMCERRAR.setForeground(java.awt.SystemColor.activeCaptionBorder);
        BTMCERRAR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images2/cerrar.png"))); // NOI18N
        BTMCERRAR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BTMCERRARMouseClicked(evt);
            }
        });
        getContentPane().add(BTMCERRAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 10, 50, 50));

        FONDO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images2/orangewall1.jpg"))); // NOI18N
        getContentPane().add(FONDO, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, -70, 720, 490));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TFnombre1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TFnombre1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TFnombre1ActionPerformed

    private void LOGINMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LOGINMouseClicked
    String nombreUsuario = TFnombre1.getText();
    String contrasena = Passe.getText();

    if (nombreUsuario.equals("admin") && contrasena.equals("123")) {
        MenuAdmin ventanaAdmin = new MenuAdmin();
        ventanaAdmin.setTitle("MENU-ADMIN");
        ventanaAdmin.setLocationRelativeTo(null);
        ventanaAdmin.setVisible(true);
    } else if (nombreUsuario.equals("cajero") && contrasena.equals("1234")) {
        MenuCajero ventanaCajero = new MenuCajero();
        ventanaCajero.setTitle("MENU-VENTA");
        ventanaCajero.setLocationRelativeTo(null);
        ventanaCajero.setVisible(true);
    } else if (nombreUsuario.equals("inventario") && contrasena.equals("12345")) {
        MenuInventario ventanaInventario = new MenuInventario();
        ventanaInventario.setTitle("MENU-INVENTARIO");
        ventanaInventario.setLocationRelativeTo(null);
        ventanaInventario.setVisible(true);
    } else {
        // Si las credenciales no coinciden con ningún usuario válido, muestra un mensaje de error o realiza alguna otra acción.
        error.setText("Credenciales incorrectas.");
    }

    this.setVisible(false);
            
    }//GEN-LAST:event_LOGINMouseClicked

    private void BTMCERRARMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTMCERRARMouseClicked

            System.exit(0);
    }//GEN-LAST:event_BTMCERRARMouseClicked

    private void PasseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PasseActionPerformed
    

    
   public static void main(String args[]) {
    
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            LOG ventana = new LOG();
            ventana.setTitle("LOGIN");
            // Centrar la ventana en medio de la pantalla
            ventana.setLocationRelativeTo(null);
            
            ventana.setVisible(true);
        }
    });
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTMCERRAR;
    private javax.swing.JLabel FONDO;
    private javax.swing.JLabel ICON;
    private javax.swing.JLabel LOGIN;
    private javax.swing.JLabel Lcontraseña;
    private javax.swing.JLabel Lnombre;
    private javax.swing.JPasswordField Passe;
    private javax.swing.JTextField TFnombre1;
    private javax.swing.JLabel error;
    // End of variables declaration//GEN-END:variables
}
